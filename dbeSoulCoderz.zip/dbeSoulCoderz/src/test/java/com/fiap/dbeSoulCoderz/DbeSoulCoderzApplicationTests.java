package com.fiap.dbeSoulCoderz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbeSoulCoderzApplicationTests {

	@Test
	void contextLoads() {
	}

}
